<?php
	header("Access-Control-Allow-Origin:*", true);
	$host = 'jordan-portfolio.dyjix.fr';
	$port = '3306';
	$dbname = 'cordova';
	$Hostname = 'jojo_admin_cordova';
	$Mdp = 'G6arl^86';

	try{
		$bdd = new PDO ("mysql:host=$host;dbname=$dbname;charset=utf8", $Hostname, $Mdp);
		$bdd->exec("SET CHARACTER SET utf8");
		$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch (Exception $e){
		die ('Erreur : ' . $e->getMessage());
	}	

	ini_set('display_error', 0);
	error_reporting(1);							
?>