<?php
		header("Access-Control-Allow-Origin:*", true);
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
}
// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
}
	include "connexion.php";

	//****** Monuments ******// 

	$reqMonu = $bdd->query('SELECT * FROM monuments_all'); 
	$data = array(); 
	$i=0; 

	while ($donneesMonu = $reqMonu->fetch()) 
	{ 
		$data[$i]["id"] = $donneesMonu["id"]; 
		$data[$i]["nom"] = $donneesMonu["nom"]; 
		$data[$i]["description"] = $donneesMonu["description"]; 
		$data[$i]["image"] = $donneesMonu["image"]; 
		$data[$i]["longitude"] = $donneesMonu["longitude"]; 
		$data[$i]["latitude"] = $donneesMonu["latitude"]; 
		$i++; 
	} 
	$reqMonu->closeCursor(); 
	header('Content-Type:Application/json'); 
	echo json_encode($data); 

?>