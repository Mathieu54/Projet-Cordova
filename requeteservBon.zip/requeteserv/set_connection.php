<?php
	header("Access-Control-Allow-Origin:*", true);
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
}
// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
}
	require_once("connexion.php");
	
	$iden = $_GET['identifiant']; 
	$password = $_GET['motdepasse']; 

	$sql = $bdd->prepare('SELECT * FROM users WHERE identifiant = :identifiant AND mdp = :mdp ;'); 
	$sql->bindParam(':identifiant', $iden); 
	$sql->bindParam(':mdp', $password); 
	$sql->execute(); 
	$data = array(); 
	if($donnees = $sql->fetch()) 
	{ 
		$data["resultat"] = "valide";
		$data["id"] = $donnees["id"];
	}
	else{
		$data["resultat"] = "[Erreur] identifiant ou mot de passe incorrect !";
	}
	echo json_encode($data);
	$sql->closeCursor(); 
?>