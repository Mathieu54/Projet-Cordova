<?php
		header("Access-Control-Allow-Origin:*", true);
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
}
// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
}
	include "connexion.php";

	//****** MonumentsVisited ******// 
	$id_user = $_GET['user'];
	$reqMonuVis = $bdd->query('SELECT * FROM monuments_all, monuments_visited, users WHERE monuments_all.id = id_monuments AND id_users = users.id AND users.id = "'.$id_user.'";'); 
	$data = array(); 
	$i=0; 

	while ($donneesMonu = $reqMonuVis->fetch()) 
	{ 
		$data[$i]["id_monuments"] = $donneesMonu["id_monuments"]; 
		$data[$i]["id_users"] = $donneesMonu["id_users"]; 
		$i++; 
	} 
	$reqMonuVis->closeCursor(); 
	header('Content-Type:Application/json'); 
	echo json_encode($data); 
?>